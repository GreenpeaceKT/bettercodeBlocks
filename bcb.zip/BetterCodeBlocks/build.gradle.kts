version = "0.1.0"

description = "Appear Syntax highlight!!!!!!"

aliucord {

    changelog.set("""
        changelog is here !!!!!
    """.trimIndent())
    
    
}