package com.discord.utilities.textprocessing;

import com.discord.simpleast.core.node.StyleNode.a;

public final class Rules$createCodeBlockRule$codeStyleProviders$1<RC> implements a<RC> {
    public static final Rules$createCodeBlockRule$codeStyleProviders$1 INSTANCE = new Rules$createCodeBlockRule$codeStyleProviders$1();

    public Iterable<?> get(RC rc) {
        return null;
    }
}
