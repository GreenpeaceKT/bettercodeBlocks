package com.discord.utilities.textprocessing;

import com.discord.simpleast.core.node.StyleNode.a;

public final class Rules$createCodeBlockRule$codeStyleProviders$3<RC> implements a<RC> {
    public static final Rules$createCodeBlockRule$codeStyleProviders$3 INSTANCE = new Rules$createCodeBlockRule$codeStyleProviders$3();

    public Iterable<?> get(RC rc) {
        return null;
    }
}
