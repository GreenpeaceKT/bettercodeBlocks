package com.discord.utilities.textprocessing;

import com.discord.simpleast.core.node.StyleNode.a;

public final class Rules$createCodeBlockRule$codeStyleProviders$4<RC> implements a<RC> {
    public static final Rules$createCodeBlockRule$codeStyleProviders$4 INSTANCE = new Rules$createCodeBlockRule$codeStyleProviders$4();

    public Iterable<?> get(RC rc) {
        return null;
    }
}
