package b.a.t.a;

import java.util.Map;

public final class a {
    public Map<String, Object> a;
}
